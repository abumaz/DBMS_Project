<?php
include('config.php');
session_start();
$uname = $_POST["uname"];
$pass = $_POST["Password"];
$qry=mysqli_query($con,"select * from customer where c_name='$uname' and password='$pass'");
if(mysqli_num_rows($qry))
{
	$_SESSION['user']=$usr['user_id'];
	{
		header('location:book.html');
	}	
	echo "$_SESSION";
}
else
{
	$_SESSION['error']="Login Failed!";
	header("location:login.html");
}
?>