<?php
    session_start();
    include('config.php');
    extract($_POST);
    mysqli_query($con,"insert into customer values(NULL,'$uname','$Password','email','$phone_no')");
    $id=mysqli_insert_id($con);
    mysqli_query($con,"update customer set cid=$id where email_id=%email)");
    $_SESSION['user']=$id;
    header('location:movie.php');
?>