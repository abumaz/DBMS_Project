<!doctype html>
<html class="no-js" lang="">

<head>
  <meta charset="utf-8">
  <title></title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <meta property="og:title" content="">
  <meta property="og:type" content="">
  <meta property="og:url" content="">
  <meta property="og:image" content="">

  <link rel="manifest" href="site.webmanifest">
  <link rel="apple-touch-icon" href="icon.png">
  <!-- Place favicon.ico in the root directory -->

  <link rel="stylesheet" href="css/normalize.css">
  <link rel="stylesheet" href="css/main.css">
  <meta name="theme-color" content="#fafafa">
</head>

<body>
          <nav>
      <input type="checkbox" id="click">
      <label for="click" class="menu-btn">
        <i class="fas fa-bars"></i>
      </label>
      <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="movies_events.php">Movies</a></li>
        <!--
          <li><a href="book.html">Book Tickets</a></li>
          <li><a href="movies_events.php">Movies</a></li>
        -->
        <li><?php if(isset($_SESSION['user'])){
        $us=mysqli_query($con,"select * from tbl_registration where user_id='".$_SESSION['user']."'");
        $user=mysqli_fetch_array($us);?><a href="profile.php"><?php echo $user['name'];?></a><a href="logout.php">Logout</a><?php }else{?><a href="login.php">Login</a><?php }?></li>
      </ul>
    </nav>
  <div class="containers">
    <form action="process_login.php" method="post">
     <div class="container">
       <label for="uname"><b>Username</b></label>
       <input type="text" placeholder="Enter Username" name="Email" required>

       <label for="Password"><b>Password</b></label>
       <input type="password" placeholder="Enter Password" name="Password" required>

       <button type="submit">Login</button>
     </div>
    </form>
  </div>

</body>
</html>
