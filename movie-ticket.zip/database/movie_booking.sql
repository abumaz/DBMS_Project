-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 28, 2020 at 09:42 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `movie_booking`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `admin_id` varchar(10) NOT NULL,
  `Passwords` varchar(20) NOT NULL,
  `thid` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`admin_id`, `Passwords`, `thid`) VALUES
('A01', 'db@proj1', 'T01'),
('A02', 'proj@db1', 'T02');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `cid` varchar(10) DEFAULT NULL,
  `c_name` varchar(20) NOT NULL,
  `passwords` varchar(10) NOT NULL,
  `email_id` varchar(100) NOT NULL,
  `phone_no` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`cid`, `c_name`, `passwords`, `email_id`, `phone_no`) VALUES
('c01', 'Majed', 'password', 'abdul.majed2019@vitstudent.ac.in', 999999999),
('c02', 'Testing', 'password', 'testing@testing.com', 99999999);

-- --------------------------------------------------------

--
-- Table structure for table `discount`
--

CREATE TABLE `discount` (
  `offer_code` varchar(10) DEFAULT NULL,
  `reduced_price` double NOT NULL,
  `receipt_id` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `movie`
--

CREATE TABLE `movie` (
  `movie_id` varchar(10) NOT NULL,
  `movie_name` varchar(30) NOT NULL,
  `director` varchar(30) DEFAULT NULL,
  `actors` varchar(20) DEFAULT NULL,
  `release_date` date DEFAULT NULL,
  `genre` varchar(10) DEFAULT NULL,
  `imdb_rating` decimal(2,1) NOT NULL,
  `image_location` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `movie`
--

INSERT INTO `movie` (`movie_id`, `movie_name`, `director`, `actors`, `release_date`, `genre`, `imdb_rating`, `image_location`) VALUES
('M1', 'Penguin', 'Eashvar Karthick', 'Keerthy Suresh', '0000-00-00', 'Thriller', '4.6', '/img/movie4.jpg'),
('M2', 'Silence', ' Hemant Madhukar', 'Madhavan,Anushka', '0000-00-00', 'Horror', '3.8', '/img/movie3.jpg'),
('M3', 'Sadak 2', 'Mahesh bhatt', 'Sanjay dutt,Alia Bha', '0000-00-00', 'Action', '1.1', '/img/movie2.jpg'),
('M4', 'Ka Pae Ranasingam', 'Virumandi.P', 'Vijay sethupathi,Ais', '0000-00-00', 'Drama', '7.3', '/img/movie1.jpg'),
('M5', 'V', 'Mohana Krishna', 'Nani,Aditi Rao', '0000-00-00', 'Action', '6.8', '/img/movie5.jpg'),
('M6', 'The devil all the time', 'Antonio Campos', 'Tom hooland,Robert p', '0000-00-00', 'Thriller', '7.1', '/img/movie6.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `mshow`
--

CREATE TABLE `mshow` (
  `show_id` varchar(10) NOT NULL,
  `languages` varchar(15) NOT NULL,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `movie_id` varchar(10) DEFAULT NULL,
  `hall_no` int(11) NOT NULL,
  `tid` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mshow`
--

INSERT INTO `mshow` (`show_id`, `languages`, `start_time`, `end_time`, `movie_id`, `hall_no`, `tid`) VALUES
('S01', 'Tamil', '2020-11-01 08:00:00', '2020-11-01 11:00:00', 'M1', 1, 'T01');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `receipt_id` varchar(15) NOT NULL,
  `costs` double DEFAULT NULL,
  `GST_NO` varchar(20) DEFAULT NULL,
  `payment_method` varchar(10) NOT NULL,
  `ticket_no` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `seats`
--

CREATE TABLE `seats` (
  `seat_id` varchar(10) NOT NULL,
  `seat_type` varchar(10) NOT NULL,
  `num_of_seats` int(11) DEFAULT NULL,
  `hall_no` int(11) DEFAULT NULL,
  `tid` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `seats`
--

INSERT INTO `seats` (`seat_id`, `seat_type`, `num_of_seats`, `hall_no`, `tid`) VALUES
('A1', 'Normal', 1, 1, 'T01'),
('A2', 'Normal', 1, 1, 'T01'),
('A3', 'Normal', 1, 1, 'T01'),
('A4', 'Normal', 1, 1, 'T02'),
('A5', 'Normal', 1, 1, 'T02'),
('B1', 'Family', 2, 2, 'T01'),
('B2', 'Family', 2, 2, 'T01'),
('B3', 'Family', 2, 2, 'T02'),
('B4', 'Family', 2, 2, 'T02'),
('B5', 'Family', 2, 2, 'T02');

-- --------------------------------------------------------

--
-- Table structure for table `theatre`
--

CREATE TABLE `theatre` (
  `tid` varchar(10) NOT NULL,
  `tname` varchar(20) DEFAULT NULL,
  `locations` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `theatre`
--

INSERT INTO `theatre` (`tid`, `tname`, `locations`) VALUES
('T01', 'Galaxy Cinemas', 'Vellore'),
('T02', 'Carnival cinemas', 'Vellore');

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

CREATE TABLE `tickets` (
  `ticket_no` varchar(10) NOT NULL,
  `hall_no` int(11) DEFAULT NULL,
  `seat_id` varchar(10) DEFAULT NULL,
  `show_id` varchar(10) DEFAULT NULL,
  `show_date` date DEFAULT NULL,
  `seat_no` int(11) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `tid` varchar(10) DEFAULT NULL,
  `admin_id` varchar(10) DEFAULT NULL,
  `cid` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`admin_id`),
  ADD KEY `fk_Theatr` (`thid`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`c_name`),
  ADD UNIQUE KEY `email_id` (`email_id`),
  ADD UNIQUE KEY `phone_no` (`phone_no`);

--
-- Indexes for table `discount`
--
ALTER TABLE `discount`
  ADD PRIMARY KEY (`reduced_price`),
  ADD UNIQUE KEY `offer_code` (`offer_code`),
  ADD KEY `fk_pay` (`receipt_id`);

--
-- Indexes for table `movie`
--
ALTER TABLE `movie`
  ADD PRIMARY KEY (`movie_id`);

--
-- Indexes for table `mshow`
--
ALTER TABLE `mshow`
  ADD PRIMARY KEY (`show_id`),
  ADD KEY `fk_movie` (`movie_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`receipt_id`),
  ADD KEY `fk_tic` (`ticket_no`);

--
-- Indexes for table `seats`
--
ALTER TABLE `seats`
  ADD PRIMARY KEY (`seat_id`),
  ADD KEY `fk_Theatre` (`tid`);

--
-- Indexes for table `theatre`
--
ALTER TABLE `theatre`
  ADD PRIMARY KEY (`tid`);

--
-- Indexes for table `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`ticket_no`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `admins`
--
ALTER TABLE `admins`
  ADD CONSTRAINT `fk_Theatr` FOREIGN KEY (`thid`) REFERENCES `theatre` (`tid`);

--
-- Constraints for table `discount`
--
ALTER TABLE `discount`
  ADD CONSTRAINT `fk_pay` FOREIGN KEY (`receipt_id`) REFERENCES `payment` (`receipt_id`);

--
-- Constraints for table `mshow`
--
ALTER TABLE `mshow`
  ADD CONSTRAINT `fk_movie` FOREIGN KEY (`movie_id`) REFERENCES `movie` (`movie_id`);

--
-- Constraints for table `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `fk_tic` FOREIGN KEY (`ticket_no`) REFERENCES `tickets` (`ticket_no`);

--
-- Constraints for table `seats`
--
ALTER TABLE `seats`
  ADD CONSTRAINT `fk_Theatre` FOREIGN KEY (`tid`) REFERENCES `theatre` (`tid`);

--
-- Constraints for table `tickets`
--
ALTER TABLE `tickets`
  ADD CONSTRAINT `fk_Seats` FOREIGN KEY (`seat_id`) REFERENCES `seats` (`seat_id`),
  ADD CONSTRAINT `fk_Show` FOREIGN KEY (`show_id`) REFERENCES `mshow` (`show_id`),
  ADD CONSTRAINT `fk_admin` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`admin_id`),
  ADD CONSTRAINT `fk_cust` FOREIGN KEY (`cid`) REFERENCES `customer` (`cid`),
  ADD CONSTRAINT `fk_disc` FOREIGN KEY (`price`) REFERENCES `discount` (`reduced_price`),
  ADD CONSTRAINT `fk_thetr` FOREIGN KEY (`tid`) REFERENCES `theatre` (`tid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
