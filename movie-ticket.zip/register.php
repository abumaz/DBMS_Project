<!doctype html>
<html class="no-js" lang="">

<head>
  <meta charset="utf-8">
  <title></title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <meta property="og:title" content="">
  <meta property="og:type" content="">
  <meta property="og:url" content="">
  <meta property="og:image" content="">

  <link rel="manifest" href="site.webmanifest">
  <link rel="apple-touch-icon" href="icon.png">
  <!-- Place favicon.ico in the root directory -->

  <link rel="stylesheet" href="css/normalize.css">
  <link rel="stylesheet" href="css/main.css">

  <meta name="theme-color" content="#fafafa">
   <script type="text/javascript">
    function Validate() {
        var password = document.getElementById("txtPassword").value;
        var confirmPassword = document.getElementById("txtConfirmPassword").value;
        if (password != confirmPassword) {
            alert("Passwords do not match.");
            return false;
        }
        return true;
    }
  </script>
</head>

<body>
  <?php include('header.php');?>

  <div class="containers">
    <form action="process_registration.php" method="post">
     <div class="container">

       <label for="email"><b>Email ID</b></label>
       <input type="email" placeholder="Enter Email ID" name="email" required/>

       <label for="phone"><b>Phone Number</b></label>
       <br>
       <input type="number" placeholder="Enter Phone Number" name="phone" required/><br>

       <label for="Age"><b>Age</b></label><br>
       <input type="number" placeholder="Enter Age" name="Age" required/><br>

       <label for="name"><b>Username</b></label>
       <input type="text" placeholder="Enter Username" name="name" required/>

       <label for="psw"><b>Password</b></label>
       <input type="password" placeholder="Enter Password" name="Password" required id="txtPassword"/>

       <label for="repsw"><b>Confirm Password</b></label>
       <input type="password" placeholder="Re-Enter Password" name="repsw" required id="txtConfirmPassword"/>

       <button type="submit">Login</button>
     </div>
    </form>
  </div>

</body>
<?php include("footer.php"); ?>
<style type="text/css">
  input[type=text], input[type=password], input[type=email] {
    width: 260px;
    padding: 12px 20px;
    margin: 8px 0;
    display: block;
    border: 1px solid #e43f5a;
    box-sizing: border-box;
    border-radius: 10px;
  }
  button {
    width: 260px;
  }



</style>
</html>
