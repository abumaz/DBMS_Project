<div class="footer">
	<div class="wrap">
			<div class="footer-top">
				<div class="col_1_of_4 span_1_of_4">
					<div class="footer-nav">
		                <ul>
		                   <li><a href="index.php">Home</a></li>
			  		   <li><a href="movies_events.php">Movies</a></li>
			  		   <li><a href="login.php">Login</a></li>
		                   </ul>
		              </div>
				</div>
				<div class="col_1_of_4 span_2_of_4">
					<div class="call_info">
						<p class="txt_4">Made By: Team 10</p>
						<p class="txt_3">Abdul Majed - 19BCE0942</p>
						<p class="txt_3">Logesh S - 19BCE0839</p>
						<p class="txt_3">Swarna Sai Nikil Teja - 19BCE0256</p>
					</div>
				</div>
				<div class="clear"></div>
			</div>
		</div>
	</div>
</body>
</html>

<style>
.footer {
	border-top-style: solid;
	border-width: 5px;
	border-color: #e43f5a;
}
.content {
	padding-bottom:0px !important;
}
#form111 {
                width:500px;
                margin:50px auto;
}
#search111{
                padding:8px 15px;
                background-color:#fff;
                border:0px solid #dbdbdb;
}
#button111 {
                position:relative;
                padding:6px 15px;
                left:-8px;
                border:2px solid #207cca;
                background-color:#207cca;
                color:#fafafa;
}
#button111:hover  {
                background-color:#fafafa;
                color:#207cca;
}

</style>

<script src="js/auto-complete.js"></script>
 <link rel="stylesheet" href="css/auto-complete.css">